<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="refresh" content="0;url=dist/index.html">
    <title>SB Admin</title>
    <script language="javascript">
        window.location.href = "dist/login.php"
    </script>
</head>

<body>
    Go to <a href="dist/index.html">/dist/index.html</a>
</body>

</html>