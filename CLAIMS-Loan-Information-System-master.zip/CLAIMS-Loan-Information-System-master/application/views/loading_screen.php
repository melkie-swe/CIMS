<div id="loading-container" class="preloader">
    <div id="loading-screen">
        <div class="loader"></div>
    </div>
</div>